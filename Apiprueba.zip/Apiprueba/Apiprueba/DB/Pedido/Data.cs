﻿using Apiprueba.Requests.Pedido;
using Apiprueba.Responses;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.DB.Pedido
{
    public class Data :IData
    {
        private readonly IConnection _connection;

        public Data(IConnection Connection )
        {
            _connection = Connection;
        }


        public async Task<Response> Crearpedido<T>(Pedidoenc Request, List<DetallePedido> Requestdtl)
        {
            var storeProcedure = "Usp_CrearPedido";
            try
            {
                var connection = _connection.OpenConnection(1);
                var response = await connection.QueryFirstOrDefaultAsync<T>(
                    storeProcedure,
                    new
                    {
                        Request.cedula,
                        Request.nombre,
                        Request.fecha
                       
                    },
                    commandType: CommandType.StoredProcedure
                );

               
                _connection.CloseConnection();
                if (response != null)
                {
                    int pedidoNum = Convert.ToInt32(response);
                    Response respuestadtl = await Creardetallepedido(pedidoNum, Requestdtl);
                    //INSERTAR DETALLE 
                }


                Response Respuesta = new Response()
                {
                    Result = response,
                    IsSuccess = true
                };

                if (Respuesta.Result == null)
                {
                    return new Response
                    {
                        IsSuccess = false,
                        Message = "No hay resultados"
                    };
                }

                return Respuesta;
            }
            catch (Exception ex)
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = ex.Message
                };
            }
        }

        public async Task<Response> Creardetallepedido(int PedidoNum, List<DetallePedido> Requestdtl)
        {
            int Result = 0;

            var storeProcedure = "Usp_Creardtlpedido";
            var dtl = CreateDataTable(Requestdtl);
            var connection = _connection.OpenConnection(1);
            var response = await connection.ExecuteAsync(
                storeProcedure,
                new
                {
                   PedidoNum,
                   dtl 
                },
                commandType: CommandType.StoredProcedure
            );


            _connection.CloseConnection();
            Response Respuesta = new Response()
            {
                Result = response,
                IsSuccess = true
            };

            if (Respuesta.Result == null)
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = "Probelmas al Insertar"
                };
            }

            return Respuesta;
        }

        public async Task<Response> ConsulatarPedido<T>(int PedidoNum)
        {
            int Result = 0;
            var storeProcedure = "Usp_consultarpedido";
            
            var connection = _connection.OpenConnection(1);
            var response = await connection.QueryFirstOrDefaultAsync<T>(
                storeProcedure,
                new
                {
                    PedidoNum                 
                },
                commandType: CommandType.StoredProcedure
            );


            _connection.CloseConnection();
            Response Respuesta = new Response()
            {
                Result = response,
                IsSuccess = true,
                Message="OK"
            };

            if (Respuesta.Result == null)
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = "Registro no encontrado"
                };
            }

            return Respuesta;
        }


        public async Task<Response> FacturarPedido<T>(int PedidoNum)
        {
            int Result = 0;
            var storeProcedure = "Usp_CrearFactura";

            var connection = _connection.OpenConnection(1);
            var response = await connection.QueryFirstOrDefaultAsync<T>(
                storeProcedure,
                new
                {
                    PedidoNum
                },
                commandType: CommandType.StoredProcedure
            );


            _connection.CloseConnection();
            Response Respuesta = new Response()
            {
                Result = response,
                IsSuccess = true,
                Message = "OK"
            };

            if (Respuesta.Result == null)
            {
                return new Response
                {
                    IsSuccess = false,
                    Message = "Factura no fue creada"
                };
            }

            return Respuesta;
        }

        private static DataTable CreateDataTable(List<DetallePedido> Requestdtl) 
        {
            DataTable table = new DataTable();
            table.Columns.Add("item", typeof(string));
            table.Columns.Add("cantidad", typeof(decimal));
            table.Columns.Add("preciounit", typeof(decimal));
            foreach (var dtl in Requestdtl)
            {
                table.Rows.Add(dtl.item,dtl.cantidad,dtl.precio_unit); 
            } 
            return table;
        }

        

    }
}

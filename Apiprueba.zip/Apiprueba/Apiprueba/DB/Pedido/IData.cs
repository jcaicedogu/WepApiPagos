﻿using Apiprueba.Requests.Pedido;
using Apiprueba.Responses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.DB.Pedido
{
    public interface IData
    {
        Task<Response> Crearpedido<T>(Pedidoenc Request, List<DetallePedido> Requestdtl);
        Task<Response> ConsulatarPedido<T>(int PedidoNum);
        Task<Response> FacturarPedido<T>(int PedidoNum);
    }
}

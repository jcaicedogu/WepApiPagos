﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.DB
{
    public class Conecction : IConnection
    {
        private readonly IConfiguration _configconecction;
        private IDbConnection _Connection;

        public Conecction(IConfiguration Configconnectio)
        {
            _configconecction = Configconnectio;
        }

        public void CloseConnection()
        {
            if (_Connection != null && _Connection.State == ConnectionState.Open)
            {
                _Connection.Close();
            }
        }

        public IDbConnection OpenConnection(int Conecction)
        {
            if (_Connection == null)
            {
                if (Conecction == 1)
                    _Connection = new SqlConnection(_configconecction["ConnectionStrings:PedidosWebConnection"]);
               
            }
            if (_Connection.State != ConnectionState.Open)
            {
                _Connection.Open();
            }
            return _Connection;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.DB
{
    public interface IConnection
    {
        void CloseConnection();

        IDbConnection OpenConnection(int Conecction);
    }
}

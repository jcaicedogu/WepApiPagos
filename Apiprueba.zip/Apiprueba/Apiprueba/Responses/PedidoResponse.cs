﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.Responses
{
    public class PedidoResponse
    {
        public int  PedidoNum { get; set; }
        public bool facturado { get; set; }
    }
}

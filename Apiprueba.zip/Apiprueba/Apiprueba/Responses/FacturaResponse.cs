﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.Responses
{
    public class FacturaResponse
    {
        public int FacturaNum { get; set; }
        public int pedidoNum { get; set; }
        public decimal total { get; set; }

        
    }
}

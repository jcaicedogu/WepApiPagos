﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Apiprueba.Requests.Pedido
{
    public class Insertpedidorequest
    {
        [Required]
        public Pedidoenc pedidoenc { get; set; }

        [Required]
        public List<DetallePedido> detallePedidos { get; set; }

    }
}

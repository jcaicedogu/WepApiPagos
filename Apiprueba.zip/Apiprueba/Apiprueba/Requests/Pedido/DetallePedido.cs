﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.Requests.Pedido
{
    public class DetallePedido
    {
        [Required]
        public string item { get; set; }

        [Required]
        public int cantidad { get; set; }

        [Required]
        public double precio_unit { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Apiprueba.Requests.Pedido
{
    public class Pedido
    {
        public List<DetallePedido> detalle_pedido { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Apiprueba.DB.Pedido;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Apiprueba.Requests.Pedido;
using Apiprueba.Responses;
using Apiprueba.Helpers;

namespace Apiprueba.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ApiKeyHelper]
    
    public class PedidoController : ControllerBase
    {
        private readonly IData _pedios;

        public PedidoController(IData pedios)
        {
            _pedios = pedios;
        }

        [HttpPost]
        [Route("Pedido")]
        public async Task<IActionResult> Crearpedido(Insertpedidorequest request)
        {
            try
            {
                
                if (!ModelState.IsValid)
                     return BadRequest((from state in ModelState
                                        select
                            (from error in state.Value.Errors select error.ErrorMessage)).FirstOrDefault());
                
                //CREA EL PEDIDO
                Response respuesta = await _pedios.Crearpedido<string>(request.pedidoenc,request.detallePedidos);
                if (!respuesta.IsSuccess)
                    return BadRequest(respuesta.Message);

                string Clientes = (string)respuesta.Result;
                return Ok(new { Numpedido= Clientes });  
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        [Route("Facturar")]
        public async Task<IActionResult>FacturarPedido(int PedidoNum)
        {
            try
            {
                //VALIDA SI EL PEDIDO EXISTE O NO HA SIDO FACTURADO
                Response respuesta = await _pedios.ConsulatarPedido<PedidoResponse>(PedidoNum);
                PedidoResponse PedidoResp = (PedidoResponse)respuesta.Result;
                if (PedidoResp != null)
                {
                    if (PedidoResp.facturado == true)
                    {
                        respuesta.IsSuccess = false;
                        respuesta.Message = "No se puede facturar.";
                        respuesta.Result = "El Pedido Numero:" + PedidoNum.ToString() + " ya fue Facturada";
                        return Ok(respuesta);
                    }
                    else 
                    {
                        //FACTURAR
                        respuesta = await _pedios.FacturarPedido<FacturaResponse>(PedidoNum);
                        FacturaResponse FacturaResp = (FacturaResponse)respuesta.Result;
                        return Ok(FacturaResp);
                    }

                }
                else
                {
                    respuesta.Result = "El Pedido Numero:" + PedidoNum.ToString() + " No existe";
                    return Ok(respuesta);
                }
                //CREAR
                // Response respuesta = await _pedios.Crearpedido<string>(request.pedidoenc, request.detallePedidos);
                if (!respuesta.IsSuccess)
                    return BadRequest(respuesta.Message);
                //PedidoResponse PedidoResp = (PedidoResponse)respuesta.Result;
                
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


    }
}
